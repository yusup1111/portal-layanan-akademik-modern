# EduServe — Portal Layanan Akademik

Website demo responsif untuk portal layanan akademik mahasiswa.

## File
- `index.html` — struktur halaman
- `style.css` — desain responsif dan aksesibilitas
- `script.js` — pencarian, filter kategori, menu mobile, dan validasi simulasi formulir

## Cara menjalankan
1. Ekstrak folder proyek.
2. Buka folder di Visual Studio Code.
3. Buka `index.html` langsung di browser atau gunakan ekstensi Live Server.

## Catatan
Formulir ini hanya simulasi di sisi browser. Data tidak dikirim ke server atau disimpan secara permanen. Untuk penggunaan kampus sesungguhnya, sambungkan backend yang aman dan sesuaikan nama layanan, waktu proses, serta kebijakan privasi dengan kampus terkait.
